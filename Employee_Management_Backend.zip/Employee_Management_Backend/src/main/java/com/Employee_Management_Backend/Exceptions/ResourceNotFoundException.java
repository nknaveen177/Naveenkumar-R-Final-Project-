package com.Employee_Management_Backend.Exceptions;

public class ResourceNotFoundException extends Exception{
	
	public ResourceNotFoundException(String message) {
		super(message);
	}

}
